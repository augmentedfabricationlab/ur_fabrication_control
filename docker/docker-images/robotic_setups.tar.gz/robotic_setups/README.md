# GKR robotic setups

This repository contains the catkin workspace for the urdf models and moveit packages for the GKR robotic setups.

On linux, clone this repository to your home directory, then open a bash console and type

    cd ~
    catkin_make
    source devel/setup.bash
